//
//  AppDelegate.swift
//  接口调试工具
//
//  Created by 李见辉 on 2018/7/3.
//  Copyright © 2018 李见辉. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate,NSWindowDelegate {
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
        

    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
    //设置点击关闭按钮后完全退出应用
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
    
    //设置缩小后点击dock里面的图标后放大
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if flag {
            return true
        }else{
            sender.windows[0].makeKeyAndOrderFront(self)
            return true
        }
    }
    

}

