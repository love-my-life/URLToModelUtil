//
//  StringExtension.swift
//  JSONExport
//
//  Created by lijianhui on 11/2/17.
//  Copyright (c) 2017 李见辉. All rights reserved.

import Foundation

extension String{
    /**
    Very simple method converts the last characters of a string to convert from plural to singular. For example "parties" will be changed to "party" and "stars" will be changed to "star"
    The method does not handle any special cases, like uncountable name i.e "people" will not be converted to "person"
    */
    func toSingular() -> String
    {
        var singular = self
        let length = self.count
        if length > 3{
            
            let range = self.index(endIndex, offsetBy: -3) ..< self.endIndex
            let lastThreeChars = self.substring(with: range)
            if lastThreeChars == "ies" {
                singular = self.replacingOccurrences(of: lastThreeChars, with: "y", options: [], range: range)
                return singular
            }
                
        }
        if length > 2{
            let range = self.index(endIndex, offsetBy: -1) ..< self.endIndex
            let lastChar = self.substring(with: range)
            if lastChar == "s" {
                singular = self.replacingOccurrences(of: lastChar, with: "", options: [], range: range)
                return singular
            }
        }
        return singular
    }
    
    /**
    Converts the first character to its lower case version
    
    - returns: the converted version
    */
    func lowercaseFirstChar() -> String{
        if self.count > 0{
            let range = startIndex ..< self.index(startIndex, offsetBy: 1)
            let firstLowerChar = self.substring(with: range).lowercased()
            
            return self.replacingCharacters(in: range, with: firstLowerChar)
        }else{
            return self
        }
        
    }
    
    /**
    Converts the first character to its upper case version
    
    - returns: the converted version
    */
    func uppercaseFirstChar() -> String{
        if self.count > 0{
            let range = startIndex ..< self.index(startIndex, offsetBy: 1)
            let firstUpperChar = self.substring(with: range).uppercased()
            
            return self.replacingCharacters(in: range, with: firstUpperChar)
        }else{
            return self
        }
        
    }
    
    /** json字符串转字典 **/
    func toDictionary() -> Dictionary<String,Any> {
        if self == "" {
            print("不是正确的字典格式")
            return [:]
        }
        let jsonData:Data = self.data(using: .utf8)!
        do {
            let json = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
            if let dict = json as? Dictionary<String,Any> {
                return dict
            }else {
                print("不是正确的字典格式")
                return Dictionary<String,Any>()
            }
        } catch {
            print("不是正确的字典格式：\(error.localizedDescription)")
        }
        return Dictionary<String,Any>()
    }
    
    /// 替换字符串
    public func replaceString(string:String, withString:String) -> String {
        return self.replacingOccurrences(of: string, with: withString, options: .literal, range: nil)
    }
    
    func jsonStringPrettyPrintedFromData(_ data: Data) -> String {
        do {
            let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
            let dataJson = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
            return NSString(data: dataJson, encoding: String.Encoding.utf8.rawValue)! as String
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        return self
    }
}
