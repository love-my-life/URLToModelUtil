//
//  ViewController.swift
//  接口调试工具
//
//  Created by 李见辉 on 2018/7/3.
//  Copyright © 2018 李见辉. All rights reserved.
//

import Cocoa
import Alamofire

class ViewController: NSViewController, NSUserNotificationCenterDelegate, NSTableViewDelegate, NSTableViewDataSource, NSTextViewDelegate {
    
    //Shows the list of files' preview
    @IBOutlet weak var tableView: NSTableView!
    
    //Connected to the top right corner to show the current parsing status
    @IBOutlet weak var statusTextField: NSTextField!
    
    //Connected to the save button
    @IBOutlet weak var saveButton: NSButton!
    
    //Connected to the JSON input text view
    @IBOutlet var sourceText: NSTextView!
    
    //Connected to the scroll view which wraps the sourceText
    @IBOutlet weak var scrollView: NSScrollView!
    
    //Connected to Constructors check box
    @IBOutlet weak var generateConstructors: NSButtonCell!
    
    //Connected to Utility Methods check box
    @IBOutlet weak var generateUtilityMethods: NSButtonCell!
    
    //Connected to root class name field
    @IBOutlet weak var classNameField: NSTextFieldCell!
    
    //Connected to parent class name field
    @IBOutlet weak var parentClassName: NSTextField!
    
    //Connected to class prefix field
    @IBOutlet weak var classPrefixField: NSTextField!
    
    //Connected to the first line statement field
    @IBOutlet weak var firstLineField: NSTextField!
    
    //Connected to the languages pop up
    @IBOutlet weak var languagesPopup: NSPopUpButton!
    
    //Inter to your url
    @IBOutlet weak var urlTextField: NSTextField!

    //Connect to result for the url for getting remote json
    @IBOutlet weak var apiProgressIndicator: NSProgressIndicator!
    
    //Connect to method to the url for getting remote json
    @IBOutlet weak var methodPopUpButton: NSPopUpButton!
    
    //请求参数
    @IBOutlet weak var parametersText: NSTextField!
    
    //拼接参数后的URL
    @IBOutlet weak var getURLText: NSTextField!
    
    @IBOutlet weak var descriptionErrorLabel: NSTextField!
    @IBOutlet weak var historyTableView: NSTableView!
    
    var selectedLang : LangModel!
    
    var dictMethodAlamofire = Dictionary<String, HTTPMethod>()
    
    //Returns the title of the selected language in the languagesPopup
    var selectedLanguageName : String
        {
        return languagesPopup.titleOfSelectedItem!
    }
    
    //Should hold list of supported languages, where the key is the language name and the value is LangModel instance
    var langs : [String : LangModel] = [String : LangModel]()
    
    //Holds list of the generated files
    var files : [FileRepresenter] = [FileRepresenter]()
    
    var historyUrls = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        saveButton.isEnabled = false
        sourceText.isAutomaticQuoteSubstitutionEnabled = false
        loadSupportedLanguages()
        setupNumberedTextView()
        setLanguagesSelection()
        loadLastSelectedLanguage()
        updateUIFieldsForSelectedLanguage()
        loadMethodPopUpButton()
    }
    
    /**
    Sets the values of languagesPopup items' titles
    */
    func setLanguagesSelection()
    {
        let langNames = Array(langs.keys).sorted()
        languagesPopup.removeAllItems()
        languagesPopup.addItems(withTitles: langNames)
        
    }
    
    /**
    Sets the needed configurations for show the line numbers in the input text view
    */
    func setupNumberedTextView()
    {
        let lineNumberView = NoodleLineNumberView(scrollView: scrollView)
        scrollView.hasHorizontalRuler = false
        scrollView.hasVerticalRuler = true
        scrollView.verticalRulerView = lineNumberView
        scrollView.rulersVisible = true
        sourceText.font = NSFont.userFixedPitchFont(ofSize: NSFont.smallSystemFontSize)
        sourceText.textColor = NSColor.red
        
    }
    
    /**
    Updates the visible fields according to the selected language
    */
    func updateUIFieldsForSelectedLanguage()
    {
        loadSelectedLanguageModel()
        if selectedLang.supportsFirstLineStatement != nil && selectedLang.supportsFirstLineStatement!{
            firstLineField.isHidden = false
            firstLineField.placeholderString = selectedLang.firstLineHint
        }else{
            firstLineField.isHidden = true
        }
        
        if selectedLang.modelDefinitionWithParent != nil || selectedLang.headerFileData?.modelDefinitionWithParent != nil{
            parentClassName.isHidden = false
        }else{
            parentClassName.isHidden = true
        }
    }
    
    /**
    Loads last selected language by user
     */
    func loadLastSelectedLanguage()
    {
        guard let lastSelectedLanguage = UserDefaults.standard.value(forKey: "selectedLanguage") as? String else{
            return
        }
        
        if langs[lastSelectedLanguage] != nil{
            languagesPopup.selectItem(withTitle: lastSelectedLanguage)
        }
    }
    
    
    //MARK: - Handling pre defined languages
    func loadSupportedLanguages()
    {
        if let langFiles = Bundle.main.urls(forResourcesWithExtension: "json", subdirectory: nil) {
            for langFile in langFiles{
                if let data = try? Data(contentsOf: langFile), let langDictionary = (try? JSONSerialization.jsonObject(with: data, options: [])) as? NSDictionary{
                    let lang = LangModel(fromDictionary: langDictionary)
                    if langs[lang.displayLangName] != nil{
                        continue
                    }
                    langs[lang.displayLangName] = lang
                }
            }
        }
        
    }

    
    
    
    // MARK: - parse the json file
    func parseJSONData(jsonData: Data!)
    {
        if let jsonString = String(data: jsonData, encoding: .utf8) {
            sourceText.string = jsonString
        }
        
    }
    
    //MARK: - Handlind events
    
    @IBAction func openJSONFiles(sender: AnyObject)
    {
        let oPanel: NSOpenPanel = NSOpenPanel()
        oPanel.canChooseDirectories = false
        oPanel.canChooseFiles = true
        oPanel.allowsMultipleSelection = false
        oPanel.allowedFileTypes = ["json","JSON"]
        oPanel.prompt = "Choose JSON file"
        
        oPanel.beginSheetModal(for: self.view.window!) { (button) in
            if button.rawValue == NSFileHandlingPanelOKButton{
                
                let jsonPath = oPanel.urls.first!.path
                let fileHandle = FileHandle(forReadingAtPath: jsonPath)
                let urlStr:String  = oPanel.urls.first!.lastPathComponent
                self.classNameField.stringValue = urlStr.replacingOccurrences(of: ".json", with: "")
                self.parseJSONData(jsonData: fileHandle!.readDataToEndOfFile())
                
            }
        }
    }
    
    
    @IBAction func toggleConstructors(_ sender: AnyObject)
    {
        generateClasses()
    }
    
    
    @IBAction func toggleUtilities(_ sender: AnyObject)
    {
        generateClasses()
    }
    
    @IBAction func rootClassNameChanged(_ sender: AnyObject) {
        generateClasses()
    }
    
    @IBAction func parentClassNameChanged(_ sender: AnyObject)
    {
        generateClasses()
    }
    
    
    @IBAction func classPrefixChanged(_ sender: AnyObject)
    {
        generateClasses()
    }
    
    
    @IBAction func selectedLanguageChanged(_ sender: AnyObject)
    {
        updateUIFieldsForSelectedLanguage()
        generateClasses()
        UserDefaults.standard.set(selectedLanguageName, forKey: "selectedLanguage")
    }
    
    
    @IBAction func firstLineChanged(_ sender: AnyObject)
    {
        generateClasses()
    }
    /** url **/
    @IBAction func urlLineChanged(_ sender: NSTextField) {
        callJson()
    }
    
    //MARK: - NSTextDelegate
    
    func textDidChange(_ notification: Notification) {
        generateClasses()
    }
    
    
    //MARK: - Language selection handling
    func loadSelectedLanguageModel()
    {
        selectedLang = langs[selectedLanguageName]
        
    }
    
    
    //MARK: - NSUserNotificationCenterDelegate
    func userNotificationCenter(_ center: NSUserNotificationCenter,
        shouldPresent notification: NSUserNotification) -> Bool
    {
        return true
    }
    
    
    //MARK: - Showing the open panel and save files
    @IBAction func saveFiles(_ sender: AnyObject)
    {
        let openPanel = NSOpenPanel()
        openPanel.allowsOtherFileTypes = false
        openPanel.treatsFilePackagesAsDirectories = false
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.canCreateDirectories = true
        openPanel.prompt = "Choose"
        openPanel.beginSheetModal(for: self.view.window!) { (button) in
            if button.rawValue == NSFileHandlingPanelOKButton{
                
                self.saveToPath(openPanel.url!.path)
                
                self.showDoneSuccessfully()
            }
        }
    }
    
    func loadMethodPopUpButton(){
        methodPopUpButton.removeAllItems()
        dictMethodAlamofire["get"] = Alamofire.HTTPMethod.get
        dictMethodAlamofire["post"] = Alamofire.HTTPMethod.post
        
        let keyToDispaly = ["get","post"]
        methodPopUpButton.addItems(withTitles: keyToDispaly)
    }
    
    /** Http **/
    func callJson() {
        
        if urlTextField.stringValue.count < 3 {
            return
        }
        var parameter = parametersText.stringValue
        let isparameter:Bool = parameter != "" && ((parameter.contains("[") && parameter.contains("]")) || (parameter.contains("{") && parameter.contains("}")))
        var str : String = urlTextField.stringValue + "?"
        
        if isparameter {
            parameter = parameter.replaceString(string: "[", withString: "{")
            parameter = parameter.replaceString(string: "]", withString: "}")
            parameter = parameter.replaceString(string: "=", withString: ":")
            parameter = parameter.replaceString(string: ";", withString: ",")
            parameter = parameter.replaceString(string: "；", withString: ",")
            parameter = parameter.replaceString(string: "，", withString: ",")
            parameter = parameter.replaceString(string: "：", withString: ":")
            if parameter.toDictionary().count != 0 {
                for (key,value):(String,Any) in parameter.toDictionary() {
                    str = str + key + "=" + "\(value)" + "&"
                }
            }
        }else{
            if parameter != "" {
                return
            }
        }
        
        
        
        self.getURLText.stringValue = str
        
        let method = dictMethodAlamofire[methodPopUpButton.titleOfSelectedItem!]!
        
        let url = urlTextField.stringValue
        self.apiProgressIndicator.layer?.backgroundColor = NSColor.gray.cgColor

        let request = Alamofire.request(url, method: method, parameters: parameter.toDictionary())
        request.responseJSON { (response) in
            if response.result.error != nil {
                self.apiProgressIndicator.layer?.backgroundColor = NSColor.red.cgColor
                self.descriptionErrorLabel.stringValue = response.result.error!.localizedDescription
                self.descriptionErrorLabel.textColor = NSColor.red
            }else{
                if let urlStr = response.request?.url?.absoluteString {
                    if urlStr != "" && !self.historyUrls.contains(urlStr) {
                        self.historyUrls.append(urlStr)
                        self.historyTableView.reloadData()
                    }
                }
                
                self.descriptionErrorLabel.stringValue = "请求成功！"
                self.descriptionErrorLabel.textColor = NSColor.green
                self.apiProgressIndicator.layer?.backgroundColor = NSColor.green.cgColor
                
                self.sourceText.string = self.sourceText.string.jsonStringPrettyPrintedFromData(response.data!)
                self.sourceText.didChangeText()
            }
        }
        
        return
    }
    
    
    
    /**
    Saves all the generated files in the specified path
    
    - parameter path: in which to save the files
    */
    func saveToPath(_ path : String)
    {
        var error : NSError?
        for file in files{
            var fileContent = file.fileContent
            if fileContent == ""{
                fileContent = file.toString()
            }
            var fileExtension = selectedLang.fileExtension
            if file is HeaderFileRepresenter{
                fileExtension = selectedLang.headerFileData.headerFileExtension
            }
            let filePath = "\(path)/\(file.className).\(fileExtension)"
            
            do {
                try fileContent.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            } catch let error1 as NSError {
                error = error1
            }
            if error != nil{
                showError(error!)
                break
            }
        }
    }
    
    
    //MARK: - Messages
    /**
    Shows the top right notification. Call it after saving the files successfully
    */
    func showDoneSuccessfully()
    {
        let notification = NSUserNotification()
        notification.title = "Success!"
        notification.informativeText = "Your \(selectedLang.langName) model files have been generated successfully."
        notification.deliveryDate = Date()

        let center = NSUserNotificationCenter.default
        center.delegate = self
        center.deliver(notification)
    }
    
    /**
    Shows an NSAlert for the passed error
    */
    func showError(_ error: NSError!)
    {
        if error == nil{
            return;
        }
        let alert = NSAlert(error: error)
        alert.runModal()
    }
    
    /**
    Shows the passed error status message
    */
    func showErrorStatus(_ errorMessage: String)
    {

        statusTextField.textColor = NSColor.red
        statusTextField.stringValue = errorMessage
    }
    
    /**
    Shows the passed success status message
    */
    func showSuccessStatus(_ successMessage: String)
    {
        
        statusTextField.textColor = NSColor.green
        statusTextField.stringValue = successMessage
    }
    
    
    
    //MARK: - Generate files content
    /**
    Validates the sourceText string input, and takes any needed action to generate the model classes and view them in the preview panel
    */
    func generateClasses()
    {
        saveButton.isEnabled = false
        var str = sourceText.string
        
        if str.count == 0{
            //Nothing to do, just clear any generated files
            files.removeAll(keepingCapacity: false)
            tableView.reloadData()
            return;
        }
        var rootClassName = classNameField.stringValue
        if rootClassName.count == 0{
            rootClassName = "RootClass"
        }
        sourceText.isEditable = false
        //Do the lengthy process in background, it takes time with more complicated JSONs
        runOnBackground {
            str = stringByRemovingControlCharacters(str)
            if let data = str.data(using: String.Encoding.utf8){
                var error : NSError?
                do {
                    let jsonData : Any = try JSONSerialization.jsonObject(with: data, options: [])
                    var json : NSDictionary!
                    if jsonData is NSDictionary{
                        //fine nothing to do
                        json = jsonData as? NSDictionary
                    }else{
                        json = unionDictionaryFromArrayElements(jsonData as! NSArray)
                    }
                    self.loadSelectedLanguageModel()
                    self.files.removeAll(keepingCapacity: false)
                    let fileGenerator = self.prepareAndGetFilesBuilder()
                    fileGenerator.addFileWithName(&rootClassName, jsonObject: json, files: &self.files)
                    fileGenerator.fixReferenceMismatches(inFiles: self.files)
                    self.files = Array(self.files.reversed())
                    runOnUiThread{
                        self.sourceText.isEditable = true
                        self.showSuccessStatus("Valid JSON structure")
                        self.saveButton.isEnabled = true
                        
                        self.tableView.reloadData()
                    }
                } catch let error1 as NSError {
                    error = error1
                    runOnUiThread({ () -> Void in
                        self.sourceText.isEditable = true
                        self.saveButton.isEnabled = false
                        if error != nil{
                            print(error!)
                        }
                        self.showErrorStatus("It seems your JSON object is not valid!")
                    })
                    
                } catch {
                    fatalError()
                }
            }
        }
    }
    
    /**
    Creates and returns an instance of FilesContentBuilder. It also configure the values from the UI components to the instance. I.e includeConstructors
    - returns: instance of configured FilesContentBuilder
    */
    func prepareAndGetFilesBuilder() -> FilesContentBuilder
    {
        let filesBuilder = FilesContentBuilder.instance
        filesBuilder.includeConstructors = (generateConstructors.state == .on)
        filesBuilder.includeUtilities = (generateUtilityMethods.state == .on)
        filesBuilder.firstLine = firstLineField.stringValue
        filesBuilder.lang = selectedLang!
        filesBuilder.classPrefix = classPrefixField.stringValue
        filesBuilder.parentClassName = parentClassName.stringValue
        return filesBuilder
    }
    
    
    
    
    //MARK: - NSTableViewDataSource
    func numberOfRows(in tableView: NSTableView) -> Int
    {
        if tableView == self.historyTableView {
            return historyUrls.count
        }else{
            return files.count
        }
    }
    
    
    //MARK: - NSTableViewDelegate
    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView?
    {
        if tableView == self.historyTableView {
            let cell = tableView.makeView(withIdentifier: NSUserInterfaceItemIdentifier(rawValue: "HistoryTableViewCell"), owner: self) as! HistoryTableViewCell
            cell.setCell(index: row, url: self.historyUrls[row])
            return cell
        }else{
            let cell = tableView.makeView(withIdentifier: NSUserInterfaceItemIdentifier(rawValue: "fileCell"), owner: self) as! FilePreviewCell
            let file = files[row]
            cell.file = file
            
            return cell
        }
        
    }
   

    
}

