//
//  HistoryTableViewCell.swift
//  接口调试工具
//
//  Created by 李见辉 on 2018/8/3.
//  Copyright © 2018 李见辉. All rights reserved.
//

import Cocoa

class HistoryTableViewCell: NSTableCellView {

    @IBOutlet weak var titleLabel: NSTextField!
    @IBOutlet var textView: NSTextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.titleLabel.wantsLayer = true
        self.titleLabel.layer?.cornerRadius = 7
        self.titleLabel.layer?.borderWidth = 1
        self.titleLabel.layer?.borderColor = NSColor.systemYellow.cgColor
        
    }
    
    func setCell(index:Int , url:String) {
        self.titleLabel.stringValue = "\(index+1)"
        self.textView.string = url
        do {
            let dataDetector = try NSDataDetector.init(types: NSTextCheckingResult.CheckingType.link.rawValue)
            let matches = dataDetector.matches(in: url, options: NSRegularExpression.MatchingOptions.init(rawValue: 0), range: NSMakeRange(0, url.count))
            for match in matches {
                let matchRange = match.range
                if match.resultType == .link {
                    let urlStr = match.url
                    self.textView.textStorage?.addAttributes([NSAttributedString.Key.link:urlStr!.absoluteString], range: matchRange)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
}
